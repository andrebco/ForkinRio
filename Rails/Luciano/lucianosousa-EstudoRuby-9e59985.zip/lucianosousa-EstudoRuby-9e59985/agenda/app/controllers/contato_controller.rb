class ContatoController < ApplicationController
  
  def cadastra
    @time = Time.now
  end
  
  def logout
    @time = Time.now
  end
end
